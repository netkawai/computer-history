// it's a dummy file, just to fill the gap

#define VERSION "?.??"
