/* A dummy file.  Minix doesn't have a u area. */
