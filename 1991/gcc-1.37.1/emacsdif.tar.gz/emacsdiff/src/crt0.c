/*  GNU Emacs -- same copyright applies */

/* Start file for minix -- I'm just hacking really */

int data_start = 0;

#ifdef NEED_ERRNO
int errno;
#endif

#ifndef DONT_NEED_ENVIRON
char **environ;
#endif

#ifndef DUMMIES
#define DUMMIES
#endif

_start (arg0)
char *arg0;
{
  int argc = *(int *)(&arg0 - 1);
  environ = &arg0 + argc + 1;

  exit (main (argc, &arg0, &arg0 + argc + 1));
}
