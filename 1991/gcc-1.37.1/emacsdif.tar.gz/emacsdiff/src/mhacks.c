#include <sys/utsname.h>
/* static char pad; */

/* abort for debugging */
abort()
{
	int a;

	printf("abort from pc=0x%x\n", *(&a + 2));
	
/*	kill(getpid(), 6); */
	exit(1);
}


/* Minix seems to be lacking in somethings so this is 
   simply a number of hacks to resolve references */

#define MAXPATHLEN 1024

short int ospeed;
char PC; 

int uname(utsstruct)
struct utsname *utsstruct;
{
	static struct utsname name = {
		"minix",
		"svax",
		"1",
		"5",
		"386",
		"1"
	};

	*utsstruct = name;
	return(0);
}

getwd(buf)
char *buf;
{
	getcwd(buf,MAXPATHLEN);
}

int getpgrp(pid)
int pid;
{
	return(0);
}

int setpgrp(pid)
int pid;
{
	return(pid);
}


