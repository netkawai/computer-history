	.text
	.align 4

	.globl isru
isru:
	mov	%bl,%cl
	shr	%cl,%eax
	ret
