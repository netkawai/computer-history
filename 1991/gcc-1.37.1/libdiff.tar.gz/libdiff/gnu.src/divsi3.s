	.text
	.align	4
	.globl ___divsi3
 ___divsi3:
	push	%edx
	mov	8(%esp),%eax
	cdq
	idivl	12(%esp)
	pop	%edx
	ret

	.text
	.align	4
	.globl ___udivsi3
 ___udivsi3:
	push	%edx
	mov	8(%esp),%eax
	sub	%edx,%edx
	divl	12(%esp)
	pop	%edx
	ret
