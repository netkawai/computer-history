	.text
	.align 4

	.globl isr
isr:
	mov	%bl,%cl
	sar	%cl,%eax
	ret
