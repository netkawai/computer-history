	.text
	.align 4

	.globl imod
imod:
	cdq
	idiv	%ebx
	mov	%edx,%eax
	ret
