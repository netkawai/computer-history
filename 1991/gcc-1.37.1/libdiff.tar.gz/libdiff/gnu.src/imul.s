	.text
	.align 4

	.globl imul_
	.globl imul_u
imul_:
imul_u:
	imul	%ebx
	ret
