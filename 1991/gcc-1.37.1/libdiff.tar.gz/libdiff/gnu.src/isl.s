	.text
	.align 4

	.globl isl
	.globl islu
isl:
islu:
	mov	%bl,%cl
	shl	%cl,%eax
	ret
