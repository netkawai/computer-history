	.text
	.align 4

	.globl idiv_
idiv_:
	cdq
	idiv	%ebx
	ret
