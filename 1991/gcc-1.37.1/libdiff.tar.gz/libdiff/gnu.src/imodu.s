	.text
	.align 4

	.globl imodu
imodu:
	xor	%edx,%edx
	div	%ebx
	mov	%edx,%eax
	ret
