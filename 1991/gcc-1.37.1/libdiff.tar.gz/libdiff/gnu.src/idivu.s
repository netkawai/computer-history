	.text
	.align 4

	.globl idiv_u
idiv_u:
	xor	%edx,%edx
	div	%ebx
	ret
