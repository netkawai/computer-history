	.file	"cruddy-atof.c"
gcc_compiled.:
.text
	.align 4
.globl _atof
_atof:
	pushl %ebp
	movl %esp,%ebp
	subl $24,%esp
	pushl %edi
	pushl %esi
	pushl %ebx
	movl 8(%ebp),%edi
	movl $0,-20(%ebp)
	movl $0,-24(%ebp)
	movl $10,%ebx
	pushl $0
	call ___floatsidf
	addl $4,%esp
	addl $-8,%esp
	fstpl (%esp)
	popl %eax
	popl %edx
	movl %eax,-8(%ebp)
	movl %edx,-4(%ebp)
	pushl %ebx
	call ___floatsidf
	addl $4,%esp
	fstpl -16(%ebp)
	cmpb $45,(%edi)
	jne L2
	movl $1,-20(%ebp)
	jmp L22
	.align 4
L2:
	cmpb $43,(%edi)
	jne L23
L22:
	incl %edi
	jmp L23
	.align 4
L7:
	cmpb $57,(%edi)
	jg L6
	pushl -12(%ebp)
	pushl -16(%ebp)
	pushl -4(%ebp)
	pushl -8(%ebp)
	call ___muldf3
	addl $16,%esp
	addl $-8,%esp
	fstpl (%esp)
	popl %ebx
	popl %esi
	movsbl (%edi),%eax
	addl $-48,%eax
	pushl %eax
	incl %edi
	call ___floatsidf
	addl $4,%esp
	addl $-8,%esp
	fstpl (%esp)
	popl %eax
	popl %edx
	pushl %edx
	pushl %eax
	pushl %esi
	pushl %ebx
	call ___adddf3
	addl $16,%esp
	fstpl -8(%ebp)
L23:
	cmpb $47,(%edi)
	jg L7
L6:
	movb (%edi),%al
	incl %edi
	cmpb $46,%al
	je L24
	cmpl $0,-20(%ebp)
	jne L26
	jmp L17
	.align 4
L13:
	cmpb $57,(%edi)
	jg L25
	pushl -12(%ebp)
	pushl -16(%ebp)
	pushl -4(%ebp)
	pushl -8(%ebp)
	call ___muldf3
	addl $16,%esp
	addl $-8,%esp
	fstpl (%esp)
	popl %ebx
	popl %esi
	movsbl (%edi),%eax
	addl $-48,%eax
	pushl %eax
	incl %edi
	call ___floatsidf
	addl $4,%esp
	addl $-8,%esp
	fstpl (%esp)
	popl %eax
	popl %edx
	pushl %edx
	pushl %eax
	pushl %esi
	pushl %ebx
	call ___adddf3
	addl $16,%esp
	fstpl -8(%ebp)
	incl -24(%ebp)
L24:
	cmpb $47,(%edi)
	jg L13
	jmp L25
	.align 4
L16:
	pushl -12(%ebp)
	pushl -16(%ebp)
	pushl -4(%ebp)
	pushl -8(%ebp)
	call ___divdf3
	addl $16,%esp
	fstpl -8(%ebp)
L25:
	movl -24(%ebp),%eax
	decl -24(%ebp)
	testl %eax,%eax
	jg L16
	cmpl $0,-20(%ebp)
	je L17
L26:
	pushl -4(%ebp)
	pushl -8(%ebp)
	call ___negdf2
	addl $-8,%esp
	fstpl (%esp)
	popl %eax
	popl %edx
	jmp L18
	.align 4
L17:
	movl -8(%ebp),%eax
	movl -4(%ebp),%edx
L18:
	pushl %edx
	pushl %eax
	fldl (%esp) 
	addl $8,%esp
	leal -36(%ebp),%esp
	popl %ebx
	popl %esi
	popl %edi
	leave
	ret
