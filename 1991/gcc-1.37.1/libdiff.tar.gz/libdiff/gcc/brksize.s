		.globl _brksize
		.data
_brksize: 	.long _end
