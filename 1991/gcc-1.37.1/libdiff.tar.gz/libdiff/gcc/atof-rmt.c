#include <stdio.h>

double atof(s)
char *s;
{
    double f;

    sscanf(s, "%lf", &f);
    return f;
}
