double atof(s)
char *s;
{
	double f, ten, zero;
	int neg=0, dp=0, iten=10, izero=0;

	f = zero = izero;
	ten = iten;

	if(*s == '-')
		neg=1, s++;
	else if(*s == '+')
		s++;

	while(*s >= '0' && *s <= '9')
		f = f*ten + (*s++ - '0');
	if(*s++ != '.')
		return neg ? -f : f;
	while(*s >= '0' && *s <= '9')
		f = f*ten + (*s++ - '0'), dp++;

	while(dp-- > 0)
		f /= ten;
	return neg ? -f : f;
}

