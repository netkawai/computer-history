	.text
	.align	4
	.globl _setjmp
_setjmp:
	pop	%ecx			# eip
	mov	0(%esp),%edx
	mov	%ebp,0(%edx)
	mov	%esp,4(%edx)
	mov	%ecx,8(%edx)
	mov	%ebx,12(%edx)
	mov	%esi,16(%edx)
	mov	%edi,20(%edx)
	sub	%eax,%eax		# non-jump return
	jmp	%ecx

	.align	4
	.globl _longjmp
_longjmp:
	mov	4(%esp),%edx		# jb
	mov	8(%esp),%eax		# value
	cmp	$1,%eax			# fixup 0 value to 1 (avoid branches)
	adc	$0,%al			# change %eax to 1 iff it was 0
	mov	0(%edx),%ebp
	mov	4(%edx),%esp
	mov	12(%edx),%ebx
	mov	16(%edx),%esi
	mov	20(%edx),%edi
	jmp	8(%edx)
