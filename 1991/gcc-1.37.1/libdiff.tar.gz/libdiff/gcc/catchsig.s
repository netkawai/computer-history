.globl _begsig

	.text
	.align	4
_begsig:
	pusha				# save registers (32 bytes)
	pushw	%ds			# 2 bytes each seg reg
	pushw	%es
	pushw	%fs
	pushw	%gs
	pushl	__M+4			# save status of last system call
	movl	32+2+2+2+2+4(%esp),%eax	# signal number from stack before save
	push	%eax			# is argument to signal handler
	call	___vectab-4(,%eax,4)	# index is signal number - 1
	pop	%eax			# discard signal number argument
	popl	__M+4			# restore status of last system call
	popw	%gs			# restore registers
	popw	%fs
	popw	%es
	popw	%ds
	popa
	addl	$4,%esp			# discard signal number again
	iret
