	.text
	.align	4
	.globl _send
_send:
	push	%ebx
	mov	8(%esp),%eax		# src_dest
	mov	12(%esp),%ebx		# m_ptr
	mov	$1,%ecx			# sys_call(SEND, src_dest, message)
	int	$33			# trap to the kernel
	pop	%ebx
	ret

	.align	4
	.globl _receive
_receive:
	push	%ebx
	mov	8(%esp),%eax
	mov	12(%esp),%ebx
	mov	$2,%ecx			# sys_call(RECEIVE, src_dest, message)
	int	$33
	pop	%ebx
	ret

	.align	4
	.globl _sendrec
_sendrec:
	push	%ebx
	mov	8(%esp),%eax
	mov	12(%esp),%ebx
	mov	$3,%ecx			# sys_call(SENDREC, src_dest, message)
	int	$33
	pop	%ebx
	ret
