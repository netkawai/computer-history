# hacked to set up a fp handler to deal with 80387 instructions

	.text
	.align	4
	.globl crtso
crtso:
	sub	%ebp,%ebp		# clear for backtrace of core files
	mov	(%esp),%eax		# argc
	lea	4(%esp),%edx		# argv
	lea	8(%esp,%eax,4),%ecx	# envp
	mov	%ecx,(_environ)
	push	%ecx
	push	%edx
	push	%eax
	push	$___fphandler
	push	$8			# SIGFPE
	call	_signal
	pop	%eax
	pop	%eax
	call	_main
	push	%eax			# exit status
	call	_exit
crt_oops:
	jmp	crt_oops		# exit can fail when break < message

	.data
	.align	4
	.long	0,0,0,0,0,0,0,0		# food for null pointer bugs

	.comm _environ, 4
